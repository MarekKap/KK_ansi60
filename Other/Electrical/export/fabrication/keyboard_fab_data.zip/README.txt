keyboard-PTH.drl - EXCELLON pokovene diery
keyboard-B_Cu.gbr - GERBER RS274-X zadna medena vrstva pohlad zo strany suciastok
keyboard-B_Mask.gbr - GERBER RS274-X zadna nepajiva maska pohlad zo strany suciastok
keyboard-B_SilkS.gbr - GERBER RS274-X popisky predna vrstva pohlad zo strany suciastok
keyboard-Edge_Cuts.gbr - GERBER RS274-X rezne hrany pohlad zo strany suciastok
keyboard-F_Cu.gbr - GERBER RS274-X predna medena vrstva pohlad zo strany suciastok
keyboard-F_Mask.gbr - GERBER RS274-X predna nepajiva maska pohlad zo strany suciastok